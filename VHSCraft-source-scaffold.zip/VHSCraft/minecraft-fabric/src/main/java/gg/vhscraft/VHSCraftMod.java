package gg.vhscraft;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;

public final class VHSCraftMod implements ModInitializer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path bridgePath;

    @Override
    public void onInitialize() {
        bridgePath = resolveBridgePath();
        try {
            Files.createDirectories(bridgePath.getParent());
            if (!Files.exists(bridgePath)) writeJson(bridgePath, emptyBridge());
        } catch (IOException e) {
            System.err.println("[VHS Craft] Could not initialize bridge: " + e.getMessage());
        }
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("vhscraft")
                .then(CommandManager.literal("status").executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    player.sendMessage(Text.literal("VHS Craft bridge: " + bridgePath), false);
                    return 1;
                }))
                .then(CommandManager.literal("sync").executes(ctx -> importStock(ctx.getSource().getPlayerOrThrow())))
                .then(CommandManager.literal("export-held")
                    .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 64))
                        .executes(ctx -> exportHeld(ctx.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(ctx, "count")))))
            )
        );
        System.out.println("[VHS Craft] Bridge ready at " + bridgePath);
    }

    private static int importStock(ServerPlayerEntity player) {
        try {
            JsonObject root = readBridge();
            JsonArray stock = root.has("stock") && root.get("stock").isJsonArray() ? root.getAsJsonArray("stock") : new JsonArray();
            int delivered = 0;
            int skipped = 0;
            for (int i = 0; i < stock.size(); i++) {
                if (!stock.get(i).isJsonObject()) { skipped++; continue; }
                JsonObject row = stock.get(i).getAsJsonObject();
                String itemId = row.has("item") ? row.get("item").getAsString() : "";
                int quantity = row.has("quantity") ? row.get("quantity").getAsInt() : 1;
                quantity = Math.max(1, Math.min(64, quantity));
                Identifier id = Identifier.tryParse(itemId);
                if (id == null || !Registries.ITEM.containsId(id)) { skipped++; continue; }
                Item item = Registries.ITEM.get(id);
                ItemStack stack = new ItemStack(item, quantity);
                if (player.getInventory().insertStack(stack)) delivered++;
                else {
                    player.dropItem(stack, false);
                    delivered++;
                }
            }
            root.addProperty("lastMinecraftSync", Instant.now().toString());
            root.addProperty("lastMinecraftSyncPlayer", player.getName().getString());
            root.addProperty("lastMinecraftDeliveredRows", delivered);
            root.addProperty("lastMinecraftSkippedRows", skipped);
            writeJson(bridgePath, root);
            player.sendMessage(Text.literal("VHS Craft: delivered " + delivered + " stock row(s); skipped " + skipped + "."), false);
            return delivered;
        } catch (Exception e) {
            player.sendMessage(Text.literal("VHS Craft sync failed: " + e.getMessage()), false);
            return 0;
        }
    }

    private static int exportHeld(ServerPlayerEntity player, int count) {
        ItemStack held = player.getMainHandStack();
        if (held.isEmpty()) {
            player.sendMessage(Text.literal("Hold a Minecraft item first."), false);
            return 0;
        }
        try {
            JsonObject root = readBridge();
            JsonArray exported = new JsonArray();
            JsonObject row = new JsonObject();
            row.addProperty("item", Registries.ITEM.getId(held.getItem()).toString());
            row.addProperty("quantity", count);
            row.addProperty("source", "minecraft-java");
            exported.add(row);
            root.add("minecraftExport", exported);
            root.addProperty("lastMinecraftExport", Instant.now().toString());
            writeJson(bridgePath, root);
            player.sendMessage(Text.literal("VHS Craft: exported " + count + " x " + Registries.ITEM.getId(held.getItem()) + " to bridge file."), false);
            return 1;
        } catch (Exception e) {
            player.sendMessage(Text.literal("VHS Craft export failed: " + e.getMessage()), false);
            return 0;
        }
    }

    private static Path resolveBridgePath() {
        String override = System.getenv("VHSCraft_BRIDGE");
        if (override != null && !override.isBlank()) return Path.of(override).toAbsolutePath().normalize();
        String localAppData = System.getenv("LOCALAPPDATA");
        if (localAppData != null && !localAppData.isBlank()) return Path.of(localAppData, "VHSCraft", "bridge.json");
        return Path.of(System.getProperty("user.home"), ".vhscraft", "bridge.json");
    }

    private static JsonObject emptyBridge() {
        JsonObject root = new JsonObject();
        root.addProperty("schemaVersion", 1);
        root.add("stock", new JsonArray());
        root.add("minecraftExport", new JsonArray());
        return root;
    }

    private static JsonObject readBridge() throws IOException {
        if (!Files.exists(bridgePath)) return emptyBridge();
        try {
            JsonObject parsed = JsonParser.parseString(Files.readString(bridgePath, StandardCharsets.UTF_8)).getAsJsonObject();
            if (!parsed.has("schemaVersion")) parsed.addProperty("schemaVersion", 1);
            return parsed;
        } catch (RuntimeException badJson) {
            throw new IOException("bridge.json is invalid JSON; fix it and retry", badJson);
        }
    }

    private static void writeJson(Path path, JsonObject root) throws IOException {
        Files.createDirectories(path.getParent());
        Path temp = path.resolveSibling(path.getFileName() + ".tmp");
        Files.writeString(temp, GSON.toJson(root), StandardCharsets.UTF_8);
        try { Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
        catch (IOException unsupportedAtomicMove) { Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING); }
    }
}
