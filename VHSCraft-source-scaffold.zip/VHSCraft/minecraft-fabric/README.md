# VHS Craft — Minecraft Fabric half

Fabric mod source targeting Minecraft Java 1.21.1 / Java 21. It shares `%LOCALAPPDATA%\\VHSCraft\\bridge.json` with the Retro Rewind UE4SS prototype.

Commands:
- `/vhscraft status` — show the bridge path.
- `/vhscraft sync` — read the `stock` array and deliver listed real Minecraft items to the executing player.
- `/vhscraft export-held <count>` — export the held item's registry ID and count to `minecraftExport`.

This source has not been compiled or launched here. Build with JDK 21 and Gradle 8.x via `gradle build`, then put the output JAR in a Fabric 1.21.1 instance with Fabric API installed. Verify your actual game version first.
