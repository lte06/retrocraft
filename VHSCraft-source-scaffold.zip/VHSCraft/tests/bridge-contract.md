# Manual bridge test checklist

- [ ] Start Retro Rewind with UE4SS and verify the VHSCraft loaded message.
- [ ] Press F8 and verify `%LOCALAPPDATA%\\VHSCraft\\bridge.json` is valid JSON with `schemaVersion: 1` and three demo stock rows.
- [ ] Start Minecraft Java 1.21.1 with Fabric, Fabric API, and the built VHS Craft JAR.
- [ ] Run `/vhscraft status` and confirm the same path.
- [ ] Run `/vhscraft sync` and verify bookshelves, paper, and black dye are delivered.
- [ ] Hold a Minecraft item and run `/vhscraft export-held 4`; verify `minecraftExport` is updated.
- [ ] Confirm the Minecraft sync metadata is written to the bridge JSON.
- [ ] Separately investigate and test Retro Rewind's live shop inventory hooks before calling the integration complete.
