# VHS Craft — Retro Rewind UE4SS half

This prototype uses UE4SS Lua and binds F8 to write a demo shop-stock payload to `%LOCALAPPDATA%\\VHSCraft\\bridge.json`. It deliberately does not pretend to read live shop inventory: the exact shop data objects/functions must be discovered and tested against the installed Retro Rewind build before a live hook can be written safely.

Copy `Mods/VHSCraft/` into the UE4SS Mods folder under Retro Rewind's `Binaries/Win64` directory, and enable `VHSCraft : 1` in `Mods/mods.txt` if required by your UE4SS version. UE4SS compatibility is build-dependent; back up the game folder first.

Press F8 in the game, then run `/vhscraft sync` in Minecraft Java 1.21.1 with the Fabric half installed. This tests the shared file bridge using demo data, not live store data.
