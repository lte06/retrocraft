-- VHS Craft UE4SS prototype bridge.
-- F8 writes a clearly labelled demo stock order; game-specific shop hooks are not guessed.
-- Install under RetroRewind\Binaries\Win64\Mods\VHSCraft\scripts\main.lua.

local json = [[{
  "schemaVersion": 1,
  "source": "retro-rewind-prototype",
  "stock": [
    {"item": "minecraft:bookshelf", "quantity": 2, "label": "Video store display shelf"},
    {"item": "minecraft:paper", "quantity": 8, "label": "Rental receipts"},
    {"item": "minecraft:black_dye", "quantity": 4, "label": "VHS cassette colour"}
  ],
  "minecraftExport": []
}]]

local function bridge_path()
    local base = os.getenv("LOCALAPPDATA")
    if base == nil or base == "" then
        print("[VHS Craft] LOCALAPPDATA missing; cannot resolve shared bridge file.\n")
        return nil
    end
    return base .. "\\VHSCraft\\bridge.json"
end

local function write_demo_stock()
    local path = bridge_path()
    if path == nil then return end
    local dir = os.getenv("LOCALAPPDATA") .. "\\VHSCraft"
    -- CreateDirectory is a standard Windows command; os.execute is used only for this fixed folder path.
    os.execute('if not exist "' .. dir .. '" mkdir "' .. dir .. '"')
    local file, err = io.open(path, "w")
    if file == nil then
        print("[VHS Craft] Could not write bridge file: " .. tostring(err) .. "\n")
        return
    end
    file:write(json)
    file:close()
    print("[VHS Craft] Demo stock exported to " .. path .. ". In Minecraft, run /vhscraft sync.\n")
end

print("[VHS Craft] UE4SS prototype loaded. Press F8 to export demo stock; this is not yet connected to live shop inventory.\n")
RegisterKeyBind(Key.F8, function()
    write_demo_stock()
end)
