# VHS Craft — integration prototype

VHS Craft is a source project for a local, file-based bridge between Retro Rewind (host game) and Minecraft: Java Edition (companion game).

## What is implemented in this prototype

- A UE4SS Lua mod for Retro Rewind that binds **F8** and writes a demo shop-stock payload to `%LOCALAPPDATA%\\VHSCraft\\bridge.json`.
- A Fabric mod source project for Minecraft Java **1.21.1**. In a world with cheats enabled or as an operator, `/vhscraft sync` reads the bridge file and gives the player the Minecraft items listed in `stock`.
- `/vhscraft status` shows the path the Minecraft mod is using.
- `/vhscraft export-held <count>` exports the item in the player's main hand to the bridge file as a Minecraft-originated record.
- MIT licensing for this project's original code; remixing is allowed.

## Important boundary

This is an **integration prototype, not a finished or verified game mashup**. The Retro Rewind half currently writes a demo stock payload when F8 is pressed. It does not yet read the live in-game shop inventory, customers, rental records, or cash flow. That needs game-specific UE object/function discovery against the user's exact Retro Rewind build and testing in the running game. No game assets are included.

The Minecraft Fabric source has not been compiled in this environment; Gradle is not installed here. No JAR is included, and no claim is made that the mod has been launched or tested in either game.

## Build the Minecraft half

Requirements: JDK 21 and Gradle 8.x (Fabric Loom will resolve dependencies from the configured repositories).

From `minecraft-fabric/`, run:

```sh
gradle build
```

The output JAR should be in `minecraft-fabric/build/libs/`. Install Fabric Loader and Fabric API for Minecraft 1.21.1, then place the built JAR in that instance's `mods` folder. Confirm the actual Minecraft version before using; this project targets 1.21.1.

## Install the Retro Rewind prototype

1. Use a UE4SS build known to work with your installed Retro Rewind build. Community reports indicate compatibility is build-dependent; this has not been tested against your copy.
2. Copy `retro-rewind/Mods/VHSCraft/` into the game's UE4SS `Mods/` directory (commonly under `RetroRewind\\Binaries\\Win64\\Mods\\`).
3. Enable the mod in UE4SS `Mods/mods.txt` using a line `VHSCraft : 1` if your UE4SS version uses that file.
4. Start Retro Rewind and press F8. Confirm `%LOCALAPPDATA%\\VHSCraft\\bridge.json` was created.

UE4SS can be incompatible with a particular game build, so back up files and remove/disable the mod if the game fails to start.

## First end-to-end test

1. Launch Retro Rewind and press F8.
2. Launch Minecraft Java 1.21.1 with Fabric and this mod installed.
3. Enter a world where you can use commands.
4. Run `/vhscraft status`; check the displayed bridge path matches the file written by Retro Rewind.
5. Run `/vhscraft sync`. The prototype should deliver the demo stock items to your inventory (or drop them if the inventory is full).
6. Hold a Minecraft item and run `/vhscraft export-held 4` to write a Minecraft-originated record back to the same JSON file.

This proves the shared-file transport path, not yet a live game-state integration. A proper next step is inspecting Retro Rewind's actual shop objects/functions and connecting the hook to the `stock` payload, then validating the behavior in-game.

## Bridge schema

`bridge/bridge.example.json` documents the initial schema. The `stock` array contains Minecraft item registry IDs and quantities. Invalid item IDs are skipped safely by the Minecraft side. The Minecraft mod records last-sync status in the same file.

## Licensing

MIT applies to original VHS Craft source code only. Retro Rewind, Minecraft, their assets, and their trademarks remain the property of their respective owners and are not included here.
